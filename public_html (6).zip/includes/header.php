<!-- header.php -->
<?php
// This can be reused on every page
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Hot Choccy | Free Marketing Tools</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="/assets/css/style.css" />

  <script>
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.addEventListener("DOMContentLoaded", () => {
      document.body.setAttribute('data-theme', savedTheme);
    });
  </script>
</head>
<body>
  <header class="site-header">
    <div class="container">
      <a href="/" class="logo">Hot Choccy</a>
      <nav>
        <a href="/">Home</a>
      </nav>
      <button class="toggle-mode" id="themeToggleBtn">🌙 Dark Mode</button>
    </div>
  </header>
