<!-- footer.php -->
  <footer class="site-footer">
    <div class="container">
      <p>&copy; <?php echo date("Y"); ?> Hot Choccy — Built for marketers, by marketers.</p>
    </div>
  </footer>
</body>
</html>
