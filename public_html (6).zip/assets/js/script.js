const themes = ['light', 'dark', 'purple', 'green'];
let currentTheme = localStorage.getItem('theme') || 'light';
document.body.setAttribute('data-theme', currentTheme);

const toggleBtn = document.getElementById('themeToggleBtn');
if (toggleBtn) {
  updateLabel(currentTheme);

  toggleBtn.addEventListener('click', () => {
    let index = themes.indexOf(currentTheme);
    index = (index + 1) % themes.length;
    currentTheme = themes[index];

    document.body.setAttribute('data-theme', currentTheme);
    localStorage.setItem('theme', currentTheme);
    updateLabel(currentTheme);
  });
}

function updateLabel(theme) {
  const labelMap = {
    light: '🌤 Light',
    dark: '🌙 Dark',
    purple: '🟣 Purple',
    green: '🌿 Green'
  };
  toggleBtn.textContent = `${labelMap[theme]} Theme`;
}

// Optional: keyboard shortcut Shift+T to toggle themes
document.addEventListener('keydown', (e) => {
  if (e.shiftKey && e.key.toLowerCase() === 't') {
    toggleBtn?.click();
  }
});
