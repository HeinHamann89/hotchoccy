<?php include('../includes/header.php'); ?>

<main class="container">
  <h1>Meta Tag Preview Tool</h1>
  <p>Preview how your page might appear in both desktop and mobile Google search results. Toggle truncation to simulate how Google may shorten your content.</p>

  <div class="tool-box">
    <form class="tool-form">
      <label for="metaTitle">Page Title: <span id="titleCount" class="char-count">0/60</span></label>
      <input type="text" id="metaTitle" maxlength="70" placeholder="e.g. The Ultimate Guide to Email Marketing" />

      <label for="metaDescription">Meta Description: <span id="descCount" class="char-count">0/160</span></label>
      <textarea id="metaDescription" rows="4" maxlength="200" placeholder="e.g. Learn how to master email marketing with this comprehensive guide for beginners and pros alike."></textarea>

      <label for="metaURL">URL:</label>
      <input type="text" id="metaURL" placeholder="e.g. https://example.com/guide-to-email-marketing" />

      <label><input type="checkbox" id="truncateToggle" /> Simulate Google truncation</label>
    </form>

    <div class="preview-columns">
      <div class="serp-preview desktop-preview">
        <h3>Desktop Preview</h3>
        <p class="serp-url" id="previewURLDesktop">https://example.com</p>
        <h2 class="serp-title" id="previewTitleDesktop">The Ultimate Guide to Email Marketing</h2>
        <p class="serp-description" id="previewDescriptionDesktop">Learn how to master email marketing with this comprehensive guide for beginners and pros alike.</p>
      </div>

      <div class="serp-preview mobile-preview">
        <h3>Mobile Preview</h3>
        <p class="serp-url" id="previewURLMobile">https://example.com</p>
        <h2 class="serp-title" id="previewTitleMobile">The Ultimate Guide to Email Marketing</h2>
        <p class="serp-description" id="previewDescriptionMobile">Learn how to master email marketing with this comprehensive guide for beginners and pros alike.</p>
      </div>
    </div>
  </div>
</main>

<script>
  const titleInput = document.getElementById('metaTitle');
  const descInput = document.getElementById('metaDescription');
  const urlInput = document.getElementById('metaURL');
  const truncateToggle = document.getElementById('truncateToggle');

  const previewTitleDesktop = document.getElementById('previewTitleDesktop');
  const previewDescriptionDesktop = document.getElementById('previewDescriptionDesktop');
  const previewURLDesktop = document.getElementById('previewURLDesktop');

  const previewTitleMobile = document.getElementById('previewTitleMobile');
  const previewDescriptionMobile = document.getElementById('previewDescriptionMobile');
  const previewURLMobile = document.getElementById('previewURLMobile');

  const titleCount = document.getElementById('titleCount');
  const descCount = document.getElementById('descCount');

  function updateCounts() {
    const titleLen = titleInput.value.length;
    const descLen = descInput.value.length;

    titleCount.textContent = `${titleLen}/60`;
    descCount.textContent = `${descLen}/160`;

    setScoreColor(titleCount, titleLen, 60);
    setScoreColor(descCount, descLen, 160);
  }

  function setScoreColor(el, length, max) {
    el.classList.remove('good', 'warn', 'bad');
    if (length <= max) {
      el.classList.add(length > max * 0.9 ? 'warn' : 'good');
    } else {
      el.classList.add('bad');
    }
  }

  function truncateText(text, limit) {
    return text.length > limit ? text.substring(0, limit).trim() + '…' : text;
  }

  function updatePreview() {
    const title = titleInput.value || 'The Ultimate Guide to Email Marketing';
    const desc = descInput.value || 'Learn how to master email marketing with this comprehensive guide for beginners and pros alike.';
    const url = urlInput.value || 'https://example.com';

    const trunc = truncateToggle.checked;
    const titleText = trunc ? truncateText(title, 60) : title;
    const descText = trunc ? truncateText(desc, 160) : desc;

    // Update both views
    previewTitleDesktop.textContent = titleText;
    previewDescriptionDesktop.textContent = descText;
    previewURLDesktop.textContent = url;

    previewTitleMobile.textContent = titleText;
    previewDescriptionMobile.textContent = descText;
    previewURLMobile.textContent = url;

    updateCounts();
  }

  [titleInput, descInput, urlInput, truncateToggle].forEach(el => {
    el.addEventListener('input', updatePreview);
  });

  updatePreview();
</script>

<?php include('../includes/footer.php'); ?>
