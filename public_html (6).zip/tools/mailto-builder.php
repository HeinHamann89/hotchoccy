<?php include('../includes/header.php'); ?>

<main class="container">
  <h1>Mailto Link Generator</h1>
  <p style="text-align; center;">Quickly generate a custom mailto link with subject, body, CC, and BCC fields.</p>

  <div class="tool-box">
    <form id="mailtoForm" class="tool-form">
      <input type="email" id="mailto" placeholder="To (e.g. hello@example.com)" required />
      <input type="text" id="subject" placeholder="Subject (optional)" />
      <textarea id="body" rows="4" placeholder="Body (optional)"></textarea>
      <input type="email" id="cc" placeholder="CC (optional)" />
      <input type="email" id="bcc" placeholder="BCC (optional)" />
    </form>

    <div class="result-box" style="margin-top: 2rem;">
      <label for="mailtoResult"><strong>Your Mailto Link:</strong></label>
      <textarea id="mailtoResult" readonly rows="3" style="width: 100%; padding: 1rem; margin-top: 0.5rem; border-radius: 10px; border: 1px solid #ccc;"></textarea>
      <button id="copyMailto" class="share-btn" style="margin-top: 1rem;">Copy Link</button>
      <p id="copyMsg" style="display:none; color:green; font-size: 0.9rem;">Copied to clipboard!</p>
    </div>
  </div>
</main>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const mailto = document.getElementById('mailto');
    const subject = document.getElementById('subject');
    const body = document.getElementById('body');
    const cc = document.getElementById('cc');
    const bcc = document.getElementById('bcc');
    const result = document.getElementById('mailtoResult');
    const copyBtn = document.getElementById('copyMailto');
    const copyMsg = document.getElementById('copyMsg');

    // Create and insert test button
    const testBtn = document.createElement('button');
    testBtn.textContent = 'Test Mailto';
    testBtn.className = 'share-btn';
    testBtn.style.marginLeft = '1rem';
    copyBtn.after(testBtn);

    const inputs = [mailto, subject, body, cc, bcc];

    function updateMailtoLink() {
      const to = encodeURIComponent(mailto.value);
      const params = new URLSearchParams();

      if (subject.value) params.append('subject', subject.value);
      if (body.value) params.append('body', body.value);
      if (cc.value) params.append('cc', cc.value);
      if (bcc.value) params.append('bcc', bcc.value);

      const fullLink = params.toString() ? `mailto:${to}?${params.toString()}` : `mailto:${to}`;
      result.value = fullLink;

      if (fullLink.length > 500) {
        result.style.borderColor = 'orange';
        result.title = 'This link is quite long. You might want to shorten it using Bitly or TinyURL.';
      } else {
        result.style.borderColor = '#ccc';
        result.title = '';
      }
    }

    inputs.forEach(input => input.addEventListener('input', updateMailtoLink));

    copyBtn.addEventListener('click', () => {
      if (result.value) {
        navigator.clipboard.writeText(result.value).then(() => {
          copyMsg.style.display = 'block';
          setTimeout(() => copyMsg.style.display = 'none', 2000);
        });
      }
    });

    testBtn.addEventListener('click', () => {
      if (result.value.startsWith('mailto:')) {
        window.location.href = result.value;
      }
    });
  });
</script>


<?php include('../includes/footer.php'); ?>
