<?php include('../includes/header.php'); ?>

<main class="container">
  <h1>UTM URL Builder</h1>
  <p style="text-align; center;">Add UTM parameters to your URLs to track marketing campaigns in tools like Google Analytics.</p>

  <div class="tool-box">
    <form id="utmForm" class="tool-form">

      <label for="preset"><strong>Choose a Platform Preset</strong></label>
      <select id="preset">
        <option value="">-- Select a Platform --</option>
        <option value="google">Google Ads</option>
        <option value="facebook">Facebook Ads</option>
        <option value="instagram">Instagram (Organic)</option>
        <option value="email">Email Campaign</option>
      </select>

      <input type="url" id="baseURL" placeholder="Website URL (e.g. https://example.com)" required title="The final destination URL where your traffic should land." />

      <input type="text" id="utmSource" placeholder="utm_source (e.g. google, facebook)" required title="Where the traffic is coming from – like a platform, website, or email list." />

      <input type="text" id="utmMedium" placeholder="utm_medium (e.g. cpc, email, social)" required title="The marketing medium – such as email, CPC, banner, etc." />

      <input type="text" id="utmCampaign" placeholder="utm_campaign (e.g. summer_sale)" required title="The name of your campaign to group all traffic under." />

      <input type="text" id="utmTerm" placeholder="utm_term (optional – keyword targeting)" title="Used for paid search keywords (e.g. shoes+for+men)." />

      <input type="text" id="utmContent" placeholder="utm_content (optional – A/B test info)" title="Differentiate links in the same ad (e.g. image vs. button)." />
    </form>

    <div class="result-box" style="margin-top: 2rem;">
      <label for="utmResult"><strong>Your UTM URL:</strong></label>
      <textarea id="utmResult" readonly rows="3" style="width: 100%; padding: 1rem; margin-top: 0.5rem; border-radius: 10px; border: 1px solid #ccc;"></textarea>
      <button id="copyUTM" class="share-btn" style="margin-top: 1rem;">Copy URL</button>
      <p id="copyMsg" style="display:none; color:green; font-size: 0.9rem;">Copied to clipboard!</p>
    </div>
  </div>
</main>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const baseURL = document.getElementById('baseURL');
    const utmSource = document.getElementById('utmSource');
    const utmMedium = document.getElementById('utmMedium');
    const utmCampaign = document.getElementById('utmCampaign');
    const utmTerm = document.getElementById('utmTerm');
    const utmContent = document.getElementById('utmContent');
    const utmResult = document.getElementById('utmResult');
    const copyBtn = document.getElementById('copyUTM');
    const copyMsg = document.getElementById('copyMsg');
    const preset = document.getElementById('preset');

    const inputs = [baseURL, utmSource, utmMedium, utmCampaign, utmTerm, utmContent];

    function buildUTMUrl() {
      if (!baseURL.value || !utmSource.value || !utmMedium.value || !utmCampaign.value) {
        utmResult.value = "";
        return;
      }

      try {
        const url = new URL(baseURL.value);
        url.searchParams.set("utm_source", utmSource.value);
        url.searchParams.set("utm_medium", utmMedium.value);
        url.searchParams.set("utm_campaign", utmCampaign.value);

        if (utmTerm.value) url.searchParams.set("utm_term", utmTerm.value);
        if (utmContent.value) url.searchParams.set("utm_content", utmContent.value);

        utmResult.value = url.toString();
      } catch (e) {
        utmResult.value = "Please enter a valid base URL.";
      }
    }

    inputs.forEach(input => input.addEventListener('input', buildUTMUrl));

    preset.addEventListener('change', function () {
      const option = preset.value;

      if (option === "google") {
        utmSource.value = "google";
        utmMedium.value = "cpc";
        utmCampaign.value = "summer_sale";
      } else if (option === "facebook") {
        utmSource.value = "facebook";
        utmMedium.value = "paid_social";
        utmCampaign.value = "fb_launch";
      } else if (option === "instagram") {
        utmSource.value = "instagram";
        utmMedium.value = "organic_social";
        utmCampaign.value = "insta_promo";
      } else if (option === "email") {
        utmSource.value = "newsletter";
        utmMedium.value = "email";
        utmCampaign.value = "june_update";
      }

      buildUTMUrl();
    });

    copyBtn.addEventListener('click', function () {
      if (utmResult.value) {
        navigator.clipboard.writeText(utmResult.value).then(() => {
          copyMsg.style.display = 'block';
          setTimeout(() => copyMsg.style.display = 'none', 2000);
        });
      }
    });
  });
</script>

<?php include('../includes/footer.php'); ?>
