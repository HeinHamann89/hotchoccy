<?php include('../includes/header.php'); ?>

<main class="container">
  <h1>Conversion Rate Calculator</h1>
  <p style="text-align: center;">Enter the number of visitors and conversions to calculate your conversion rate.</p>

  <div class="tool-box">
    <form id="conversionForm" class="tool-form">
      <input type="number" id="visitors" placeholder="Total Visitors" min="0" required />
      <input type="number" id="conversions" placeholder="Total Conversions" min="0" required />
      <button type="submit">Calculate</button>
    </form>

    <div id="result" class="result-box" style="display: none;">
      <p>Your conversion rate is:</p>
      <h2 id="conversionRate" class="success-animation">0%</h2>

      <button id="shareBtn" class="share-btn">Copy Shareable Link</button>
      <p id="copyMsg" style="display:none; color:green; font-size: 0.9rem;">Link copied to clipboard!</p>
    </div>
  </div>

  <section class="industry-stats">
    <h3>💡 Industry Benchmarks</h3>
    <p>Typical conversion rates vary by industry. Here are a few examples:</p>
    <ul>
      <li><strong>E-commerce:</strong> 1.8% – 3.2%</li>
      <li><strong>SaaS:</strong> 3% – 7%</li>
      <li><strong>Finance:</strong> 5% – 10%</li>
      <li><strong>Healthcare:</strong> 3% – 5%</li>
      <li><strong>Travel & Hospitality:</strong> 1% – 2.5%</li>
    </ul>
    <p>Compare your results to your industry to see how you stack up.</p>
  </section>
</main>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('conversionForm');
    const visitorsInput = document.getElementById('visitors');
    const conversionsInput = document.getElementById('conversions');
    const resultBox = document.getElementById('result');
    const conversionRateDisplay = document.getElementById('conversionRate');
    const shareBtn = document.getElementById('shareBtn');
    const copyMsg = document.getElementById('copyMsg');

    // Parse and apply URL params if present
    const params = new URLSearchParams(window.location.search);
    const visitors = params.get('visitors');
    const conversions = params.get('conversions');

    if (visitors && conversions) {
      visitorsInput.value = visitors;
      conversionsInput.value = conversions;
      calculateAndDisplay(visitors, conversions);
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const visitorsVal = parseFloat(visitorsInput.value);
      const conversionsVal = parseFloat(conversionsInput.value);

      if (visitorsVal > 0 && conversionsVal >= 0) {
        calculateAndDisplay(visitorsVal, conversionsVal);
        updateURLParams(visitorsVal, conversionsVal);
      } else {
        conversionRateDisplay.textContent = 'Invalid input';
        resultBox.style.display = 'block';
      }
    });

    shareBtn.addEventListener('click', function () {
      navigator.clipboard.writeText(window.location.href).then(() => {
        copyMsg.style.display = 'block';
      });
    });

    function calculateAndDisplay(visitors, conversions) {
      const rate = (conversions / visitors) * 100;
      conversionRateDisplay.textContent = rate.toFixed(2) + '%';
      resultBox.style.display = 'block';
      copyMsg.style.display = 'none';
    }

    function updateURLParams(visitors, conversions) {
      const newURL = new URL(window.location.href);
      newURL.searchParams.set('visitors', visitors);
      newURL.searchParams.set('conversions', conversions);
      window.history.replaceState({}, '', newURL);
    }
  });
</script>

<?php include('../includes/footer.php'); ?>
