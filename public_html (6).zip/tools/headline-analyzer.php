<?php include('../includes/header.php'); ?>

<main class="container">
  <h1>Headline Analyzer</h1>
  <p>Evaluate your headline's effectiveness based on structure, emotion, urgency, and more.</p>

  <div class="tool-box">
    <form class="tool-form">
      <label for="headline">Enter a headline:</label>
      <input type="text" id="headline" placeholder="e.g. 10 Ways to Grow Your Business Fast" />
    </form>

    <div id="results" class="result-box" style="display:none;">
      <p><strong>Character Count:</strong> <span id="charCount">0</span></p>
      <p><strong>Word Count:</strong> <span id="wordCount">0</span></p>
      <p><strong>Type:</strong> <span id="headlineType">—</span></p>
      <p><strong>Emotion Detected:</strong> <span id="emotion">—</span></p>
      <p><strong>Urgency Score:</strong> <span id="urgency" class="score-indicator">—</span></p>
      <p><strong>Emoji Count:</strong> <span id="emojiCount" class="score-indicator">0</span></p>
      <p><strong>Suggestions:</strong></p>
      <ul id="suggestions"></ul>
    </div>
  </div>
</main>

<script>
  const headlineInput = document.getElementById('headline');
  const resultsBox = document.getElementById('results');
  const charCount = document.getElementById('charCount');
  const wordCount = document.getElementById('wordCount');
  const headlineType = document.getElementById('headlineType');
  const emotion = document.getElementById('emotion');
  const urgency = document.getElementById('urgency');
  const emojiCountEl = document.getElementById('emojiCount');
  const suggestionsList = document.getElementById('suggestions');

  const emotionalWords = ['amazing', 'proven', 'secret', 'instantly', 'boost', 'easy', 'free', 'ultimate', 'unbelievable'];
  const urgencyWords = ['now', 'instantly', 'limited', 'hurry', 'today', 'ending', 'urgent', 'last chance', 'soon'];
  const emojiRegex = /[\u{1F600}-\u{1F64F}\u{2700}-\u{27BF}\u{1F300}-\u{1F6FF}]/gu;

  function setScoreLevel(el, score) {
    el.classList.remove('low-score', 'med-score', 'high-score');
    if (score === 0) el.classList.add('low-score');
    else if (score <= 2) el.classList.add('med-score');
    else el.classList.add('high-score');
  }

  function analyzeHeadline(text) {
    const words = text.trim().split(/\s+/).filter(w => w.length > 0);
    const length = text.length;
    const lower = text.toLowerCase();
    const emotionDetected = emotionalWords.find(word => lower.includes(word)) || 'Neutral';
    const emojis = text.match(emojiRegex);
    const emojiCount = emojis ? emojis.length : 0;
    const urgencyScore = urgencyWords.filter(word => lower.includes(word)).length;

    // Headline Type
    let type = 'General';
    if (/^how to/i.test(text)) type = 'How-To';
    else if (/^\d/.test(text)) type = 'List';
    else if (text.endsWith('?')) type = 'Question';

    // Suggestions (AI-style)
    const suggestions = [];
    if (length < 30) suggestions.push('Consider lengthening your headline for clarity.');
    if (length > 70) suggestions.push('Consider shortening to make it more scannable.');
    if (!/\d/.test(text)) suggestions.push('Numbers often increase engagement — try adding one.');
    if (!emotionalWords.some(word => lower.includes(word))) suggestions.push('Add emotional or power words to increase impact.');
    if (!/[a-z]+ing|will|can|boost|get|increase|learn/i.test(text)) {
      suggestions.push("Consider using action verbs to make it more engaging.");
    }
    if (emotionDetected === 'Neutral') {
      suggestions.push("Try adding emotional or power words for more impact.");
    }

    // Update UI
    charCount.textContent = length;
    wordCount.textContent = words.length;
    headlineType.textContent = type;
    emotion.textContent = emotionDetected.charAt(0).toUpperCase() + emotionDetected.slice(1);
    urgency.textContent = `${urgencyScore}/5`;
    emojiCountEl.textContent = emojiCount;

    setScoreLevel(urgency, urgencyScore);
    setScoreLevel(emojiCountEl, emojiCount);

    suggestionsList.innerHTML = '';
    suggestions.forEach(s => {
      const li = document.createElement('li');
      li.textContent = s;
      suggestionsList.appendChild(li);
    });

    resultsBox.style.display = text.length > 0 ? 'block' : 'none';
  }

  headlineInput.addEventListener('input', () => {
    analyzeHeadline(headlineInput.value);
  });
</script>

<?php include('../includes/footer.php'); ?>
