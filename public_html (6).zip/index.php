<?php include('includes/header.php'); ?>

<main class="container">
  <h1>Free Marketing Tools – Built for Speed and Simplicity</h1>
  <input type="text" id="searchInput" placeholder="Search tools..." />
  
  <ul id="toolList">
    <li><a href="tools/conversion-rate-calculator.php">Conversion Rate Calculator</a></li>
    <li><a href="tools/utm-builder.php">UTM URL Builder</a></li>
    <li><a href="tools/mailto-builder.php">Mailto Link Generator</a></li>
    <li><a href="tools/headline-analyzer.php">Headline Analyzer</a></li>
    <li><a href="tools/character-counter.php">Character Counter</a></li>
    <li><a href="tools/meta-preview.php">Meta Tag Preview Tool</a></li>
    <li><a href="tools/google-ads-preview.php">Google Ads Preview</a></li>
    <li><a href="tools/subject-line-tester.php">Email Subject Line Tester</a></li>
    <li><a href="tools/emoji-picker.php">Emoji Picker</a></li>
    <li><a href="tools/markdown-to-html.php">Markdown to HTML Converter</a></li>
  </ul>
</main>

<?php include('includes/footer.php'); ?>
<script src="assets/js/script.js"></script>
